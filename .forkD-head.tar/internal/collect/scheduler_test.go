package collect_test

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/NaejEL/opnview/internal/collect/collecttest"
	"github.com/NaejEL/opnview/internal/collect/core"
	"github.com/NaejEL/opnview/internal/config"
	"github.com/NaejEL/opnview/internal/plugin"
)

// The scheduler tests.
//
// The property under test is failure isolation. A firewall with no Suricata, a resolver with
// its reporting off, a lease backend the firewall does not separate — each of those makes one
// collector fail every pass, and none of them may stall the others. Without that, a
// product installed on an ordinary firewall would stop collecting the filter log because the
// intrusion-detection engine is not installed.
//
// The clock is injected, so nothing here sleeps.

// TestEveryLoopRunsAtItsConfiguredCadence pins the wiring: every collector, runtime
// discovery, the probe round, the retention purge and the resolver's cache and local-data
// reads, each at the interval its own justification carries. The core loops are the keys of
// the map below and nowhere else, so adding one is adding a key; the plugin loops are derived
// from the loaded built-ins. This comment and the test's name state no count to fall out of date.
func TestEveryLoopRunsAtItsConfiguredCadence(t *testing.T) {
	t.Parallel()
	harness := collecttest.NewProbeHarness(t)
	settings := config.Defaults()
	tasks := harness.Collector.Tasks(config.NewLive(settings))

	wanted := map[string]time.Duration{
		"runtime discovery":   settings.DiscoveryInterval,
		"availability probes": settings.DiscoveryInterval,
		// One loop per core kind whose file declares a poll cadence and whose coordinator registered a
		// pass, named after the kind, at the default its kind file declares.
		"firewall_log":       10 * time.Second,
		"security_event":     60 * time.Second,
		"measurement_sample": 300 * time.Second,
		"dhcp_lease":         300 * time.Second,
		"dns_lookup":         60 * time.Second,
		"retention purge":    settings.PurgeInterval,
		// The two reads of the resolver-cache cycle, at decision 4's 60 s and 300 s.
		"resolver_cache":      60 * time.Second,
		"resolver_local_data": 300 * time.Second,
		// The broker's own loop: its scheduler and its subscriptions, which returns only when the
		// run stops (A12 of the broker amendment).
		"firewall broker": time.Minute,
		// The live passes, at the finest live cadence a loaded plugin declares: the insight plugin's
		// live_cadence_seconds, 10 s by default (C3 of the backend-completion cycle). A tick with no
		// live-interest lease does nothing.
		"live sampling": 10 * time.Second,
	}
	// The plugin loops are not listed by hand: one per provider of the loaded built-ins that states a
	// cadence, named "<kind> <provider key>", at the cadence its manifest declares. A built-in plugin
	// added as a directory gets its loop checked here without an edit to this file.
	pluginLoops := 0
	for _, registration := range plugin.Builtins().All() {
		if registration.Cadence > 0 {
			wanted[registration.Kind+" "+registration.Key] = registration.Cadence
			pluginLoops++
		}
	}
	// And one loop per derivation of the loaded built-ins, at its declared cadence, an hour when it declares none
	// (it then runs on its other triggers alone).
	for _, derivation := range harness.Collector.SourceSet.Derivations() {
		interval := derivation.Cadence()
		if interval <= 0 {
			interval = time.Hour
		}
		wanted["derivation "+derivation.Name()] = interval
		// A derivation run after a core kind's passes hears of them by their notifications: the listening loop runs,
		// restarted every minute should its connection drop.
		if len(derivation.AfterPasses()) > 0 {
			wanted["notifications"] = time.Minute
		}
	}
	if pluginLoops == 0 {
		t.Fatal("no built-in provider states a cadence, so the plugin loops this test derives are none " +
			"and it no longer checks them")
	}
	if len(tasks) != len(wanted) {
		names := make([]string, 0, len(tasks))
		for _, task := range tasks {
			names = append(names, task.Name)
		}
		t.Fatalf("the scheduler has %d loops, want %d: %q", len(tasks), len(wanted), names)
	}
	for _, task := range tasks {
		interval, named := wanted[task.Name]
		if !named {
			t.Errorf("the loop %q is not one this test knows about", task.Name)
			continue
		}
		if task.Interval() != interval {
			t.Errorf("the %q loop runs every %v, want %v", task.Name, task.Interval(), interval)
		}
		if task.Run == nil {
			t.Errorf("the %q loop has no work", task.Name)
		}
		delete(wanted, task.Name)
	}
	for name := range wanted {
		t.Errorf("there is no %q loop", name)
	}

	// The purge is the one loop that does not run at start-up: there is nothing to purge in
	// the first second of a run, and a delete competing with the first ingest buys nothing.
	for _, task := range tasks {
		if task.Name == "retention purge" && task.RunAtStart {
			t.Error("the purge runs at start-up, which competes with the first ingest for nothing")
		}
		if task.Name != "retention purge" && !task.RunAtStart {
			t.Errorf("the %q loop does not run at start-up, so its first pass waits a full "+
				"interval for no reason", task.Name)
		}
	}
}

// TestACollectorThatFailsDoesNotStopTheOthers is the isolation, driven by an injected clock.
func TestACollectorThatFailsDoesNotStopTheOthers(t *testing.T) {
	t.Parallel()
	clock := collecttest.NewFixedClock(collecttest.ReferenceInstant())
	failing := errors.New("collect_test: this source is unavailable on this firewall")

	var counts [4]atomic.Int64
	reported := make(chan string, 64)

	tasks := []core.Task{
		{Name: "the failing one", Interval: core.FixedInterval(time.Second), RunAtStart: true,
			Run: func(context.Context) error { counts[0].Add(1); return failing }},
		{Name: "the first healthy one", Interval: core.FixedInterval(time.Second), RunAtStart: true,
			Run: func(context.Context) error { counts[1].Add(1); return nil }},
		{Name: "the second healthy one", Interval: core.FixedInterval(time.Second), RunAtStart: true,
			Run: func(context.Context) error { counts[2].Add(1); return nil }},
		{Name: "the third healthy one", Interval: core.FixedInterval(time.Second), RunAtStart: true,
			Run: func(context.Context) error { counts[3].Add(1); return nil }},
	}

	ctx, cancel := context.WithCancel(context.Background())
	var finished sync.WaitGroup
	finished.Add(1)
	go func() {
		defer finished.Done()
		if err := core.Run(ctx, clock, tasks, func(name string, _ error) { reported <- name }); err != nil {
			t.Errorf("the run returned %v", err)
		}
	}()

	// Three rounds. Each round waits until every loop is waiting for a tick and then
	// wakes them all, so every loop gets the same number of passes and a loop that had
	// stalled would be visible as a missing waiter rather than as a low count.
	const rounds = 3
	for round := 0; round < rounds; round++ {
		clock.AwaitWaiters(t, len(tasks))
		if woken := clock.ReleaseAll(); woken != len(tasks) {
			t.Fatalf("round %d woke %d of %d loops", round, woken, len(tasks))
		}
	}
	// Wait for the last round to come back round before stopping, so the counts below are
	// not racing the final pass.
	clock.AwaitWaiters(t, len(tasks))
	cancel()
	clock.ReleaseAll()
	finished.Wait()

	for index := range counts {
		if ran := counts[index].Load(); ran < int64(rounds) {
			t.Errorf("loop %d ran %d times, want at least %d; a failing sibling stalled it",
				index, ran, rounds)
		}
	}
	if counts[0].Load() < int64(rounds) {
		t.Error("the failing loop stopped after its first failure rather than continuing")
	}
	close(reported)
	failures := 0
	for name := range reported {
		if name != "the failing one" {
			t.Errorf("the loop %q was reported as failing", name)
		}
		failures++
	}
	if failures < rounds {
		t.Errorf("the failing loop was reported %d times; each failed pass has to be reported",
			failures)
	}
}

// TestTheRunLoopStopsOnCancellationWithinABoundedDeadline is the shutdown guarantee the
// service unit depends on.
func TestTheRunLoopStopsOnCancellationWithinABoundedDeadline(t *testing.T) {
	t.Parallel()
	clock := collecttest.NewFixedClock(collecttest.ReferenceInstant())
	tasks := []core.Task{
		{Name: "a loop that waits", Interval: core.FixedInterval(time.Hour), RunAtStart: true,
			Run: func(context.Context) error { return nil }},
		{Name: "another loop that waits", Interval: core.FixedInterval(time.Hour), RunAtStart: true,
			Run: func(context.Context) error { return nil }},
	}

	ctx, cancel := context.WithCancel(context.Background())
	stopped := make(chan error, 1)
	go func() { stopped <- core.Run(ctx, clock, tasks, nil) }()

	cancel()
	select {
	case err := <-stopped:
		// A cancelled context is how the program stops, not a failure: returning an error
		// for it would make an ordinary stop look like a crash to whatever reads the exit
		// code.
		if err != nil {
			t.Fatalf("a clean cancellation returned %v", err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("the run loop did not stop within five seconds of cancellation")
	}
}

// TestALoopWithNoCadenceIsNotRun keeps a misconfigured interval from becoming a loop that
// runs as fast as the processor allows.
func TestALoopWithNoCadenceIsNotRun(t *testing.T) {
	t.Parallel()
	clock := collecttest.NewFixedClock(collecttest.ReferenceInstant())
	var ran atomic.Int64
	tasks := []core.Task{
		{Name: "a loop with no interval", Interval: core.FixedInterval(0), RunAtStart: true,
			Run: func(context.Context) error { ran.Add(1); return nil }},
		{Name: "a loop with no work", Interval: core.FixedInterval(time.Second), RunAtStart: true},
	}

	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := core.Run(ctx, clock, tasks, nil); err != nil {
		t.Fatalf("the run returned %v", err)
	}
	if ran.Load() != 0 {
		t.Fatalf("a loop with no cadence ran %d times", ran.Load())
	}
}

// TestAPassThatFailsBecauseTheRunIsStoppingIsNotReported keeps a stop from filling the log
// with failures that are only the stop itself.
func TestAPassThatFailsBecauseTheRunIsStoppingIsNotReported(t *testing.T) {
	t.Parallel()
	clock := collecttest.NewFixedClock(collecttest.ReferenceInstant())
	reported := make(chan string, 8)

	ctx, cancel := context.WithCancel(context.Background())
	tasks := []core.Task{{
		Name: "a loop that fails as the context closes", Interval: core.FixedInterval(time.Hour), RunAtStart: true,
		Run: func(ctx context.Context) error {
			cancel()
			return ctx.Err()
		},
	}}
	if err := core.Run(ctx, clock, tasks, func(name string, _ error) { reported <- name }); err != nil {
		t.Fatalf("the run returned %v", err)
	}
	close(reported)
	for name := range reported {
		t.Errorf("the loop %q was reported as failing, and it only failed because the run was "+
			"stopping", name)
	}
}
