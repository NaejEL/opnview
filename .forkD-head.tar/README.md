# opnview

Inter-interface visibility for a VLAN-segmented network behind an OPNsense
firewall.

OPNsense already collects the raw material — filter logs, NetFlow, DHCP
leases, DNS lookups, the Suricata event log — but never cross-references it.
`opnview` does, and answers five questions:

- which interface talks to which interface, and for how much traffic;
- what is blocked, by which rule, and who tried;
- what each client consumes, with site names instead of bare IPs;
- where the data goes, to which countries and which operators;
- which machine is behaving abnormally.

The widget everything else hangs off is the **interface × interface matrix**:
volume exchanged, allowed connections, blocked connections, matching rules. It
makes it obvious when an interface that is supposed to be isolated has started
talking to another one.

The user interface is not a fixed set of screens. You create **named canvases** and
fill each with the widgets you want, moving between them with tabs rather than
menus; a canvas can be exported to a file and imported into another
installation.

**One service and its database, installed and updated by a single command,
with nothing to set up by hand.** The database is PostgreSQL with TimescaleDB,
run beside `opnview` by the installation itself. See the storage rule in
[ROADMAP.md](ROADMAP.md), under *Rules that apply to every step*. The frontend
is served by the service. Nothing is installed on the firewall and `opnview`
changes nothing on it: it reads the REST API, read-only, and can receive the
firewall's syslog and NetFlow exports if you configure them on the firewall
yourself (see *Push sources*). Every request
to the firewall, a plugin's included, goes through `opnview`'s read-only
broker, which refuses anything but a read before it is sent.

## Status

**Under construction.** Nothing is usable yet.
Progress follows [ROADMAP.md](ROADMAP.md) — eight steps, validation after each
one. Step 1 is done: [docs/opnsense-api-survey.md](docs/opnsense-api-survey.md).
Current step: 5, correlation, classification and the matrix. Step 4 was validated
against a live OPNsense on 3 October 2026.

`opnview` now has its own accounts, and that is where credentials enter it.
On first start it creates its database and its encryption key, prints a
**one-time setup token** to the console, and serves four surfaces: create the
first account with that token, sign in, enter the firewall URL, the API key
and secret, the MaxMind account ID and licence key and the theme, and size
collection. There is no environment variable, no configuration file and no
`configure` command, and a credential changed in the interface takes effect on
the next collection pass without a restart. There are no canvases and no widgets
yet: those are steps 5 and 7.

With a MaxMind account ID and licence key, the GeoLite2 City and ASN databases
are downloaded and the public addresses the flows carry are placed against them;
the settings surface says where the databases stand. The map that shows them is
step 7.

The settings surface can fetch the certificate the firewall presents and put
its SHA-256 fingerprint in the field, so a default OPNsense, which serves its
API under a self-signed certificate, can be pinned without copying the
fingerprint by hand. Fetching stores nothing; the save beside it does.

The collection surface shows, for each kind of source the installation has, the
pair that governs its polling — how often, and how many records one request
asks for — beside the rate `opnview` has measured from its own database over the
last 24 hours, and the pair it would suggest from that rate. A suggestion is
never applied on its own: the operator fills the fields with it and saves, and
the new pair takes effect without a restart. Measuring contacts nothing.

Which implementation of a source is read is the operator's decision first and
the probe round's only where the operator left it: each one is `auto` by
default, and can be turned `on` or `off` in its kind's card on the collection
surface (see `provider` in [docs/data-model.md](docs/data-model.md)). A saved
selection is applied at once from what the last probe round found, without
contacting the firewall; before the first round of a start, it waits for that
round.

## Data sources

Five, all read through the OPNsense REST API:

|Source|Feeds|Required|
|---|---|---|
|Filter logs|the matrix, blocked traffic|yes|
|Suricata `eve.json`|alerts|no|
|NetFlow / Insight|volumes per address pair, daily|yes|
|DHCP leases|hostnames and MACs|yes|
|Resolver DNS lookups, and the resolver's cache and local data|site names; host names no lease names|the lookups yes, the cache and local data no|

The resolver may be Unbound or Dnsmasq, and the DHCP server likewise —
`opnview` detects which one is active. Suricata may be absent, installed but
stopped, or running on only some interfaces; the UI states what is covered and
what is not.

### Site names are inferred, not observed

`opnview` names sites from the resolver, by one of two methods, and records which
on every name. The first is exact evidence: the resolver's **cache**, read every
minute, holds the addresses each name resolved to, so a flow towards an address
the cache held for a name its client looked up is named after that name —
`resolver_cache_answer`. When the cache says nothing either way, the second
method, `lookup_timing`, names a flow after the single name its client looked up
in the few seconds before it. Both are **inferences**: the cache shows the client
could have been told that address when it asked for that name, not that the flow
was for it, and a client that looked up two names answering with the same address
is named after neither. The limitations section below says where both fail.

It was meant to be a fallback. Suricata's `tls` events carry the SNI and its
`dns` events the query, both alongside the real pre-NAT source address —
*observed* names, nothing guessed. The step-1 API survey established that
neither is available on OPNsense 26.7:

- there is no `dns` event type to enable — the IDS model exposes only `http`
  and `tls`;
- `tls` and `http` events can be written to `eve.json`, but the only API
  endpoint that reads that file returns alert records and silently discards
  every other event type, and the generic log endpoint cannot open a file not
  named `.log`.

Suricata therefore contributes alerts and nothing else, and the resolver remains
the only source of site names — its lookups and, since the resolver-cache cycle,
its cache. There is still no observed-name method, so the UI does not pretend
there is one: it says that names are inferred, shows the attribution rate, and
says per name which of the two methods inferred it. The evidence is in
[docs/opnsense-api-survey.md](docs/opnsense-api-survey.md).

Nor can they be received over syslog: OPNsense's syslog output of Suricata's
eve log carries alerts and no other event type (survey, *Push sources*, S13).

For the heuristic to work at all the resolver has to be logging its queries.
Turning that on is a manual step — the procedure will be documented here, and
`opnview` never performs it for you: it only ever reads.

## Push sources

Besides reading the REST API, `opnview` can **receive** what the firewall sends
when you tell it to: syslog lines and NetFlow records. Nothing changes on the
firewall unless you change it, in its own pages; `opnview` only listens. What
each export adds:

- **The filter log over TCP syslog.** Polling reads the newest page of the log
  every few seconds and records a gap when a burst outruns the page; a remote
  syslog target sends every line as it is written. While it arrives, it
  replaces polling of the filter log, and polling resumes on its own when it
  stops. Every second belongs to one path, so no line is counted twice.
- **Unbound's query and reply log**, into a table of its own: every query and
  reply line, with its client, name, type, return code, time and size. It
  cannot replace the resolver's query report, which also says whether a
  blocklist answered, and it does not.
- **NetFlow v9**, received by the built-in `netflow` plugin and stored as flow
  records. **Every interface may be captured.** Each record names the interface
  it arrived on and the one its route chose, and `opnview` joins it to the
  logged connection those name: each connection then has a second figure, its
  **measured volume** (the `netflow` measure), beside the logged one and never
  added to it. A packet the firewall exports more than once -- translated, or
  again by a VLAN's parent -- is stored as a named copy and counted once, so
  each direction of a connection is counted once. What NetFlow cannot measure
  carries a named state instead of a zero: an egress-only interface's inbound
  traffic is `ingress_not_captured`, an interface the exporter cannot attach to
  (a WireGuard tunnel, for instance) `interface_not_exported`, forwarding
  between two exported interfaces `forwarding_export_unsettled`.

**On OPNsense** (the survey's *Push sources* section is the source of every step):

1. *System > Settings > Logging*, tab *Remote*: add a target. *Transport*
   **TCP(4)** or **TCP(6)** -- only TCP may replace polling, because a datagram
   lost over UDP is invisible; *Applications* `filterlog`, or none to send every
   program, the only way to send Unbound's lines; *Hostname* the address
   `opnview` listens on; *Port* its syslog port; *rfc5424* on. Save, apply.
2. For Unbound's lines: *Services > Unbound DNS > Advanced*, *Log Queries*
   and/or *Log Replies* (OPNsense's own help warns that they slow the resolver).
3. For NetFlow: *Reporting > NetFlow*: the interfaces to capture, *Version* v9,
   and `<address>:<port>` of `opnview` among the destinations. Local collection
   (Insight) may stay on: it is one more destination, and the two run together
   on the same capture. Capture the interfaces whose traffic you want measured;
   an interface listed as egress-only has its inbound traffic named
   `ingress_not_captured`. `opnview` reads the capture as it is and never
   changes it.

**On `opnview`**, each listener is a start parameter with no default,
`--push-listen <protocol>/<transport>=<host:port>`, and, from the development
toolchain, an override file per listener whose port variable has no default:

    OPNVIEW_LISTEN=8080 OPNVIEW_SYSLOG_TCP=<port> docker compose         -f docker-compose.serve.yml -f docker-compose.push-syslog-tcp.yml         run --rm --service-ports serve

(`docker-compose.push-syslog-udp.yml` with `OPNVIEW_SYSLOG_UDP`,
`docker-compose.push-netflow.yml` with `OPNVIEW_NETFLOW_UDP`.) `--service-ports`
is required: `docker compose run` publishes no port without it. The container
runs as an unprivileged user, so a port below 1024 -- syslog's registered 514
-- fails to bind; choose one of 1024 or above, which OPNsense's target accepts.

**Only the firewall may send.** A datagram or a connection is accepted only from
the address your configured firewall URL resolves to, or one the firewall's own
interfaces hold; anything else is refused, counted, and listed in the API
catalogue. This is a check of the source address, not an authentication: a host
on the path forging the firewall's address passes it. A Docker setup that
rewrites the source address of published traffic makes every message refused --
the catalogue, and the provider's availability detail, then list the address it
saw -- and is a deployment to correct: run `opnview` with host networking, or
outside the port proxy.

**Extra senders, when the deployment cannot be corrected.** Docker Desktop's
port publishing rewrites the source of every published datagram and connection,
UDP and TCP alike, to the gateway of the compose network (`docker network
inspect` names it; the catalogue's refused senders show it too): the firewall's
own address never reaches `opnview`. The start
parameter `--push-extra-senders <address>[,<address>...]`, or from the
development toolchain the variable `OPNVIEW_PUSH_EXTRA_SENDERS`, adds addresses
accepted beside the firewall's own. It is **empty by default**.

    OPNVIEW_LISTEN=8080 OPNVIEW_NETFLOW_UDP=<port> OPNVIEW_PUSH_EXTRA_SENDERS=<gateway> \
        docker compose -f docker-compose.serve.yml -f docker-compose.push-netflow.yml \
        run --rm --service-ports serve

**The risk is yours to close.** Behind such a proxy every sender arrives with the
gateway's address, so naming it accepts **whatever reaches the published port,
from any host**: the check above no longer tells the firewall from anyone else.
Filter the published ports on the host running `opnview` -- its own firewall --
so that only the firewall's address reaches them. The catalogue's
`extra_accepted_addresses` says how many extra senders are in force.

## Alerts — what an internal IDS is actually for

An IDS on internal interfaces, behind a router that is itself behind CGNAT,
is not there to repel attacks coming from the Internet: almost none arrive.
It is there to **detect a compromised machine inside your own network** — an
IoT machine reaching a command-and-control server, an exposed container
scanning the network, an exfiltration, DNS tunnelling.

Read the alerts with that in mind, or you will be looking for the wrong thing.

## What leaves your installation

Exactly three things, and nothing else:

1. the calls to the firewall API, on your local network — the credential check
   `opnview` makes when you enter or correct your API key is one of these, to
   the same firewall, read-only, and not a separate thing;
2. the MaxMind GeoLite2 database download, which contacts a third-party server
   with your MaxMind account ID and licence key. It asks `download.maxmind.com`,
   which redirects the download to the storage host MaxMind names for it; the
   credentials go to the first and never to the second, and no other host is
   contacted. Without a licence key and an account ID, nothing is requested.
   Once a day `opnview` asks whether a newer build exists — a request MaxMind
   does not count against the 30 downloads a day a GeoLite account is allowed —
   and downloads only when one does. The databases are kept in `geoip/` in the
   data directory, and a replaced build is deleted at once.
3. the Public Suffix List download, from `publicsuffix.org`, which `opnview`
   uses to group a site name under its registrable domain (`www.example.co.uk`
   under `example.co.uk`). It carries no credential and nothing about your
   network: it asks for one public file, once a day, and only conditionally, so
   an unchanged list costs a "not modified" answer. No other host is contacted.
   The list is kept in `publicsuffix/` in the data directory; when a download
   fails, the copy already held stays in use, and before the first successful
   download no grouping is offered.

The push listeners, when you open them, are inbound: they receive what you
configured the firewall to send and make no call of their own.

No telemetry, no version check, no resource loaded from a CDN. The interface
loads nothing from anywhere: its stylesheet is served by `opnview` itself and
its fonts are the ones already on your machine.

## Limitations, stated up front

**The application only sees what crosses the router.** Two machines on the
same interface talking to each other are invisible: their traffic is switched
and never reaches the firewall. A hypervisor hosting its virtual machines
behind its own interface likewise hides all of their internal traffic. This is
not a defect, it is a property of the observation point.

**Domain attribution is a heuristic, always.** Correlating a DNS lookup with
the flow that follows it fails on client-side DNS caching, on shared CDNs where
a thousand domains sit behind one IP, and on DNS-over-TLS or DNS-over-HTTPS,
which bypasses the resolver entirely and leaves no lookup to correlate. An
attribution rate is displayed per client, and no domain is ever invented when
the correlation fails — you get the IP, the country and the operator instead.
There is no observed-name path to fall back on: see
[Site names](#site-names-are-inferred-not-observed). The cache-based method has
limits of its own: a record the resolver cached and dropped between two of
`opnview`'s reads is never seen, and a record evicted before its TTL is taken to
have been held until the TTL ran out.

**Reading the resolver's cache records every name the firewall's resolver
resolved.** Not only the names your clients looked up while `opnview` was reading
the query report: every name the resolver held in its cache, with the addresses it
resolved to, and every host override in its local data. They are stored in the
database like everything else, so they are governed by the same retention, and the
aggregate mode — no domain names — withholds them from the screens as it does the
site names, without stopping them being stored.

**Alert coverage is per interface.** Suricata may be absent, installed but
stopped, or running on only some interfaces. Alerts exist for the interfaces it
monitors and for no others; the UI states per interface whether it is covered,
rather than showing an empty panel.

**A measured record rate is a lower bound.** The collection surface sizes
polling from the records `opnview` stored. A record that was lost — lines a
filter-log page no longer reached, an `eve.json` file rotated away, lookups the
resolver's ring buffer dropped — was never stored and is counted nowhere, so the
rate the firewall's sources really produce can only be higher. The gaps
`opnview` detected are shown beside the rate; the ones it could not detect are
not.

**Volumes per address pair are daily on the firewall.** OPNsense keeps
per-address-pair traffic at a one-day resolution, for 62 days. Shorter periods
are built from `opnview`'s own history, so the 1 h and 24 h views are only as
deep as the time it has been running.

**The encryption key is a file in `opnview`'s data directory, outside the
database, and the limit is stated rather than dressed up.** Your OPNsense API secret and your MaxMind licence key
are encrypted at rest with authenticated encryption; the key that opens them is
created on first start, in the data directory, with permissions denying group
and other. **This protects a database that is copied, backed up, sent by mistake
or committed by accident, because the key file does not travel with it. It does
not protect against someone who already has the machine, who reads both.** No
scheme can, while the service starts and collects without a human — which it
must, or collection stops at every reboot until somebody signs in. That trade
was taken deliberately.

Two consequences follow, and neither is a defect:

- **back up the key file with the database dump, or separately, but do not lose it.**
  Without it the stored credentials cannot be read and have to be entered again;
  the history in the database is untouched either way;
- **a forgotten password is recovered by presenting that same key file**, and by
  nothing else. Whoever holds it already holds the decryptable secrets, so
  requiring it grants an attacker nothing they did not have — and it returns the
  installation without deleting the database.

**Replacing a credential leaves the previous one in the database's files until
PostgreSQL reclaims it, and that is said rather than glossed over.** A credential is
stored as one row, replaced in place, so no live row holds the previous value. But
PostgreSQL keeps the replaced row version until a vacuum reclaims its space, and its
write-ahead log holds it until the log segment is recycled, so for a while the
database's files hold the previous ciphertext as well as the current one. It is encrypted under the same key file, so
it discloses nothing to anyone who does not hold that file, and only a
**superseded** secret to anyone who holds both — the same people the limitation
above already names. Forcing a full checkpoint after every credential write would
close it and was weighed against the cost; it was not taken. If you rotate a
secret because it leaked, revoke it on the firewall as well, which is what makes
the old value worthless wherever a copy of it sits.

**The session cookie carries no `Secure` flag.** `opnview` serves plain HTTP
today: `Secure` would make signing in impossible, and there is no TLS story
before the packaging step. The cookie is `HttpOnly` and `SameSite=Lax`, every
mutating form carries a token that a different session's token does not satisfy,
and the session token itself is stored only as a digest — so a copy of the
database hands over no usable session. **On a network where somebody may be
reading your traffic, put `opnview` behind a reverse proxy that terminates TLS.**

## Data

The tool reconstructs per-client browsing history: that is its function, not a
side effect. It is complete by default. Configurable retention and aggregate
mode — volumes, interfaces, countries, operators, without domain names — are
options, not imposed guardrails.

It also keeps the resolver's cache: **every name the firewall's resolver resolved,
for any client and for the firewall itself, with the addresses it resolved to**,
and the resolver's local data — host overrides included. That is what lets a site
name rest on the address a name actually resolved to. It is subject to the same
retention, and the aggregate mode withholds it at the interface while it is still
stored.

In a workplace setting, informing the people concerned is a legal obligation
in most jurisdictions.

### Durability

The installation's database runs with PostgreSQL's own durability,
`synchronous_commit = on`: a commit returns only once it is written to disk, so a crash
or a power loss loses no committed row — only work not yet committed
(<https://www.postgresql.org/docs/17/runtime-config-wal.html#GUC-SYNCHRONOUS-COMMIT>).

### Backup

A backup is two things: the database, and the key file in the data directory.
The database is the installation's own PostgreSQL database; dump it with

```
pg_dump --format=custom --file=opnview.dump "host=<host> port=<port> user=<user> dbname=<database>"
```

replacing the four placeholders with that database's connection, and giving the
password through a password file or the `PGPASSWORD` environment variable rather
than on the command line. The dump without the key file restores the history but
not the stored credentials. Restore into the same TimescaleDB version, by the
procedure TimescaleDB documents for a logical backup: create the database and the
`timescaledb` extension, run `SELECT timescaledb_pre_restore();`, then
`pg_restore --dbname=<database> opnview.dump` (without `-j`), then
`SELECT timescaledb_post_restore();`. The pre-deployment checks run this exact
dump and this restore on a seeded database and compare every table's row count.

## Licence

[MIT](LICENSE).

The database is PostgreSQL with the TimescaleDB extension, run beside `opnview` by the
installation; `opnview` uses only TimescaleDB's Apache-2.0 edition, and neither links
nor redistributes it.

This product includes GeoLite Data created by MaxMind, available from
<https://www.maxmind.com>. The databases are downloaded on your own MaxMind
account, under MaxMind's GeoLite End User License Agreement, and are never part
of this repository.

The Public Suffix List is published by the Public Suffix List project at
<https://publicsuffix.org/list/> under the [Mozilla Public License
2.0](https://mozilla.org/MPL/2.0/). It is downloaded at run time and is never part
of the binary; the repository holds only an excerpt for the tests, in
`internal/suffixlist/testdata`, with the licence header it carries.
