# Roadmap — opnview

Inter-interface visibility for a VLAN-segmented network behind an OPNsense
firewall. Eight steps, **explicit validation after each one**. We never move to
the next step without agreement. If an assumption turns out to be wrong, we say
so and amend this roadmap rather than quietly working around it.

## Rules that apply to every step

- **Zero hardcoded configuration.** No interface name, VLAN name, addressing
  plan or interface count in the code, the templates or the default values.
  Everything is discovered at runtime through the API.
- **No secrets in the repository.** The OPNsense URL, API key/secret and
  MaxMind licence key are entered in the interface, never in a file to edit
  before starting.
- **Modularity is a product property, at every layer, and it is not a step's
  concern to grant or withhold.** The user's installation is not ours: a
  resolver we do not run, a DHCP server we do not use, a plugin nobody here has
  installed are all the normal case. So a *kind* of thing — a lease source, a
  lookup source, a language, a theme, a widget — is a seam, and an
  implementation of that kind is a file or a directory behind it, chosen at
  runtime by what the installation actually has. **The test: adding a second
  implementation is adding a file and a registry row, and touches nothing
  else.** Where the schema already models a kind with several implementations,
  the code has no licence to collapse them into one; a data model that is
  provider-neutral and a backend shaped around one maintainer's configuration
  is the worst of both.

- **`opnview` has its own accounts.** On first start the user creates a login
  and a password; everything else, including the firewall's URL and key, is
  configured from the interface once signed in.
  - A **password** is hashed with Argon2id, a per-user salt, and the algorithm
    parameters stored beside the hash so they can be raised later. It is never
    read back.
  - The **OPNsense secret and the MaxMind key are not passwords.** They are
    sent to those services on every call, so they are encrypted at rest with
    authenticated encryption and decrypted to be used. Hashing them would make
    the product unable to work.
  - The **encryption key is a file beside the database**, created on first
    start with restrictive permissions. **The limit is stated rather than
    dressed up:** this protects a database that is copied, backed up, sent by
    mistake or committed by accident, because the key file does not travel with
    it. It does not protect against someone who already has the machine, who
    reads both. No scheme can, while the service starts and collects without a
    human — which it must, or collection stops at every reboot until somebody
    signs in. That trade was taken deliberately. The README's limitations
    section says so in those words.
- **Read-only against the firewall.** No writes, no file read on the host:
  the authenticated REST API and nothing else. Where a firewall setting has to
  be turned on for a source to exist — the resolver query log, for instance —
  it is a manual step the user performs, documented in the README. The
  application never performs it. Read-only is enforced by the broker for every
  plugin: GET, and POST to read actions (commands starting with `search`,
  `get`, `query` or `list`, or ending with `status`), with the list of
  mutating commands checked first.
- **Three outbound calls, not one more**: the firewall API (local network),
  the MaxMind database download, and the Public Suffix List download from
  publicsuffix.org. The third was added by the maintainer's decision for step
  5A, because grouping a site name under its registrable domain needs the list,
  and the list is maintained upstream: a copy frozen into the binary would group
  every suffix added after the build wrongly, with no way to tell. It is
  refreshed daily and fetched conditionally, so an unchanged list costs a 304,
  and the previous good copy stays in use when a download fails. No telemetry,
  no version check, no resource loaded from a CDN. The connection to the
  installation's own database is not an outbound call: it goes to the
  PostgreSQL the installer set up, over a Unix socket or the installation's
  private container network, and to no other host. Images pulled at install or
  update time are installation-time downloads, not calls the product makes.
  Push listeners are inbound: they receive what the user configured the
  firewall to send, accept only the firewall's own addresses, and make no
  outbound call.
- **The observation limit is documented, not printed**: the application only
  sees what crosses the router, so every figure is a lower bound.
- **Degrade, never guess.** Suricata may be absent, installed but stopped, or
  running on only some interfaces. Which interfaces its alerts cover is a fact
  about the data, documented here; the interface does not recite it.
- **One service and its database, installed and updated by a single command.
  The user provisions nothing by hand.** The store is **PostgreSQL with the
  TimescaleDB extension** (the maintainer's decision of 11 October 2026). It
  runs beside `opnview` as part of the same installation: the installer
  creates, configures and starts it, and the user never creates a database, a
  role or a password.

  This replaces an earlier rule, written by the orchestrator rather than the
  maintainer, that storage engines be embedded libraries and that forbade
  PostgreSQL and TimescaleDB. What that rule protected was the install story,
  and the install story is kept:
  - one command installs;
  - re-running it updates;
  - one documented command backs up: `pg_dump`, plus the key file in the data
    directory.

  What changed is the judgement on the cost. SQLite's single writer, the
  hand-built calendar rollups and one shared file for every plugin's tables
  cost more than a second process does.

  **Versions are pinned:** the PostgreSQL major and the TimescaleDB release, by
  exact version and image digest, and they are changed deliberately.

  **Licence:** `opnview` uses TimescaleDB's Apache-2.0 edition only -- no
  continuous aggregate and no TimescaleDB background job
  (`docs/architecture.md`, *Storage*). `opnview` stays MIT and neither links
  nor redistributes TimescaleDB. Confirmed on 16 October 2026 (Phase E), which
  supersedes the decision of 12 October 2026 to enable the Timescale License:
  no continuous aggregate is exactly equivalent to the table it would replace
  (`docs/data-model.md`, *Storage fit*), so enabling that licence would serve
  nothing. Every database, the installation's included, runs with
  `timescaledb.license=apache`.

  **TimescaleDB's telemetry is off,** and `opnview` refuses to start if it is
  not.

  **Not permitted:**
  - a second storage engine or data store, without a maintainer decision;
  - a database reachable through a published port;
  - a database credential in the repository.

  `README.md` and `CLAUDE.md` point at this bullet rather than restating it.
- **The vocabulary is OPNsense's, and that of every product `opnview` reads. It
  never invents a term for something those products already name.** When the
  right term is not known it is researched — in
  `docs/opnsense-api-survey.md`, on `docs.opnsense.org`, or in the product's own
  documentation — or the maintainer is asked. It is never guessed and never
  embroidered to save a lookup. Where a product genuinely has no word for
  something `opnview` needs, that is stated explicitly, the term is chosen
  deliberately, and the reason is recorded next to it.

  **This rule exists because it was broken silently and nobody noticed for
  three steps.** `segment` was invented in the very first commit, before any
  research existed, and was never reconciled with what OPNsense calls the
  thing: an **interface**. The table gave itself away — `interface_identifier`,
  `device_name`, `discovered_description`, three columns describing an
  interface under a name OPNsense does not use — while
  `docs/opnsense-api-survey.md` had been carrying the real vocabulary
  (`get_interface_names`, `descr`, `link_type`) since step 1. `device` was worse
  still: it meant the network device on one table and a client machine on
  another, so one word carried two meanings and neither matched OPNsense's use
  of it. Both are fixed; the term-by-term mapping, with the source establishing
  each, is in `docs/data-model.md` under *Vocabulary*.

- **Everything is written in English** — code, docs, UI, commits. See
  `CLAUDE.md`.

## Data sources

Five, all read through the OPNsense REST API:

|Source|Feeds|Required|
|---|---|---|
|Filter logs|matrix, blocked traffic|yes|
|Suricata `eve.json` (`alert` only)|alerts|no|
|NetFlow / Insight|volumes per address pair, daily|yes|
|DHCP leases|hostnames and MACs|yes|
|Resolver DNS lookups (Unbound or Dnsmasq), and the resolver's cache and local data (Unbound)|site names (sole source); host names no lease names|the lookups yes, the cache and local data no|

The Suricata and resolver rows read differently from the original plan: see
the step-1 findings below. The resolver row gained its cache and its local data
in step 5 (`specs/SPEC-resolver-cache-attribution.md`): the cache supplies the
answer addresses the query report does not carry, so a site name can rest on
exact evidence, and the local data names hosts no DHCP lease names. Both are read
from `/api/unbound/diagnostics/*` and need no setting turned on.

## Development and test environment

No line of this project is built or tested on the host OS, and **no Go
toolchain is installed on the host**. The toolchain lives in a Debian
`trixie-slim` container defined by `Dockerfile` and `docker-compose.yml`, with
the Go version pinned and checksum-verified, and ShellCheck pinned and verified the
same way, so the shell scripts are checked in the container by `sql/schema-checks.sh`
rather than on the host. The production target is an
unprivileged Debian LXC, and a Windows host masks exactly the bug classes
`opnview` will hit: file mode and umask on the data directory and the key file,
filesystem case sensitivity, `SIGTERM` handling for the
future systemd unit, and normalising the OPNsense filter-log timestamps, which
carry neither year nor timezone.

The four project commands — `gofmt -l .`, `go vet ./...`, `go build ./...`,
`go test ./...` — run through a single canonical invocation, issued from the
repository root:

```
docker compose run --rm checks
```

That string is **identical in PowerShell and in bash**: it carries no quoting,
and it needs no knowledge of the host `PATH`.

**Two commands: the everyday suite and the pre-deployment command** (the
maintainer's test budget of 7 October 2026,
`specs/SPEC-test-budget-and-two-live-defects.md`).

- **`docker compose run --rm checks` is the everyday suite**, run by builders and
  verifiers on every iteration: `gofmt -l .`, `go vet ./...`, `go build ./...` and
  `go test -count=1 ./...` without `-race`, every test except those moved to the
  pre-deployment command. **Its `go test` wall time has a budget of 60 s**, the one
  constant `TEST_BUDGET_SECONDS` in `ci/checks.sh`: the script measures the time,
  prints it beside the container's CPU count so a slower or busier machine is
  identifiable, and fails above the budget with a message that names it. `-count=1`
  makes the time the suite's rather than a cache hit's. `go test` runs as many
  test binaries at once as the machine has physical cores (`-p`), not logical
  CPUs: the suite is bound by the test database's CPU, and on hyperthreads twice
  as many binaries only queue (measured in `ci/checks.sh`). The everyday suite's
  PostgreSQL test instance keeps its data on a tmpfs with durability off, and runs
  with autovacuum off and `wal_level = minimal` (each measured in
  `docker-compose.yml`), which nothing the suite asserts depends on; the
  pre-deployment command runs against a
  disk-backed instance with production settings. **A hard limit stops the run**:
  the whole of `checks` runs under coreutils `timeout` at
  `CHECKS_HARD_LIMIT_SECONDS`, 90 s, and fails naming it, and `go test` runs with
  the test budget as its `-timeout`; a measured budget alone cannot stop a run
  that hangs.
- **`docker compose run --rm pre-deployment` is the gate run before a
  deployment**, not on every iteration. **Its wall time has a budget of 180 s**,
  the one constant `PRE_DEPLOYMENT_BUDGET_SECONDS` in `ci/pre-deployment.sh`: it
  prints every step's wall time, the total and the CPU count, and fails above the
  budget naming it. The whole command runs under coreutils `timeout` at
  `PRE_DEPLOYMENT_HARD_LIMIT_SECONDS`, 240 s, and fails naming it; every `go test`
  in it runs with the budget as its `-timeout`. It runs on a copy of the working
  tree at the path `checks` copies it to, `/tmp/opnview-checks-tree`, because Go
  keys a compiled package by its directory: from that path, everything the
  everyday suite compiled is a hit in the shared build cache. Its steps, the
  independent ones side by side, each with its own output block and exit code:
  - **the race selection**, computed by `ci/raceselect` and never written by hand:
    a package runs under `-race` when any of its `.go` files, test files included,
    (i) holds a `go` statement, (ii) imports `sync` or `sync/atomic`, or (iv) lies
    under `internal/plugin/`: the packages that start goroutines or share mutable
    state across them. Clause (iii), serving HTTP, was retired on 16 October 2026
    (decision 2 of the spec's "Phase E: decisions after the partial build"), and its
    number is not reused: a package that only serves HTTP is excluded. Every package
    is printed, selected or excluded, with the clause that decided it, and the two
    sets together must be exactly `go list ./...`;
  - **`go test -race -count=1`** over the selected packages and **`go test
    -count=1`** over the others, both with the `predeployment` build tag, so every
    package runs exactly once; `go vet` with the build tags of every test kept out
    of the everyday suite;
  - **the broker budgets** (the `brokerbudget` tag, without `-race`, which would
    measure itself) and the push decoders' fuzz targets;
  - **the test budget's own check**, `ci/budget-self-test.sh`: it runs `checks`
    with `OPNVIEW_BUDGET_PROBE_ONLY`, which restricts its `go test` to the probe
    package, and a test-only sleep one second past the budget, and requires it to
    exit non-zero printing "over the test budget of 60 s"; it runs beside the other
    steps, most of it being the probe's sleep;
  - **`sql/schema-checks.sh`** -- the schema, the seeds at 100 000 and 1 000 000
    flow rows, the screen queries and every statement's plan at both seeds, the
    widget and data catalogue budgets at both seeds (100 000 rows at 250 ms for
    24 h and 500 ms for 30 days, 1 000 000 at 1 s and 2 s), the live budget and the
    backup round trip. The wall time of `ReclassifyEverything` on a copy of the
    large seed is out of this command since 16 October 2026: it places one address
    at a time and took 1.5 to 2 minutes alone, which the budget cannot hold; it runs
    on request, `docker compose run --rm -e OPNVIEW_RECLASSIFY_COST=1 schema-checks`.

  **The seeds are built once and reused while their digest holds.** A cold build
  of the 1 000 000-row seed takes minutes -- more than the whole budget -- so every
  seed is kept under its exact name with the digest of what it was built from
  written on it: `schema.sql`, `sql/seed.sql`, the seed's parameters, and the
  server's PostgreSQL and TimescaleDB versions. Five are kept: the 1 000 000-row
  seed, `schema_checks_scale_seed`; its purged copy, `schema_checks_scale_purged`,
  purged once per digest of the seed and of `purge.sql`, which RC-AC14 and the
  foreign-key check after it read; and the 100 000-row seeds,
  `schema_checks_main_seed`, `schema_checks_repeat_seed` -- a second build of the
  same definition, which AC7's determinism check compares with the first, both
  built again whenever their digest changes -- and `schema_checks_alt_seed`
  (Phase E decisions 9 and 11). A run whose digest matches reads the kept seed, or
  a clone of it where a check writes, and prints the digest it reused; a run whose
  digest differs builds it cold, prints the build's breakdown -- the schema apply,
  each table's generation, `VACUUM (ANALYZE)` -- and its time apart from the
  budgeted run, and announces at its start that it does. **After a change to what
  the seeds are built from, `docker compose run --rm schema-checks` builds them**:
  run on its own it has no hard limit, where the pre-deployment command would stop
  a cold build at its own. The kept seeds live on **`db-schema-checks`**, the
  schema checks' own instance, configured like `db-predeployment` on a volume of
  its own (decision 10): beside the Go suite on one instance, every `DROP
  DATABASE` of the schema checks waited for a checkpoint writing the Go suite's
  buffers too. The pre-deployment command runs with `/tmp` on the overlay
  filesystem, its non-race step against `db-predeployment` and its schema checks
  against `db-schema-checks`, both disk-backed with production durability, so the
  whole suite meets a real disk once before a deployment.
- **Moving a test out of the everyday suite** is allowed only for a `-race` check
  or a check on the 1 000 000-row seed, with the `predeployment` build tag, which
  the pre-deployment command passes to `go vet` and `go test`, never by deleting or
  skipping the test, and the test says why in a comment beside the tag. **The tests
  outside the everyday suite, exactly:** none carries the `predeployment` tag
  (`internal/store/calendar_test.go` returned to the everyday suite on 16 October
  2026); `TestReclassifyEverythingWallTimeAtTheMillionRowSeed`
  (`internal/collect/reclassifycost_test.go`, tag `reclassifycost`) reads the
  1 000 000-row seed and is run by `sql/schema-checks.sh` only when
  `OPNVIEW_RECLASSIFY_COST=1` is set; and the broker budgets
  (`internal/broker/budget_test.go` and `internal/plugin/scripthost/budget_test.go`,
  tag `brokerbudget`) are timings the race detector would distort. **The everyday
  suite fits its budget by its shared helpers, never by a list of tests**: a clone
  of the test template skips the schema apply when the database already records the
  digest of `schema.sql` (`applied_schema`); a wait for the database is a reported
  event, not a silent sleep; and `OPNVIEW_TEST_BREAKDOWN=1` prints, per package,
  where the suite's time goes (`ci/testtiming`).

**`OPNVIEW_DATA_DIR` and Git Bash.** The data directory of the scripts the
pre-deployment command runs is `OPNVIEW_DATA_DIR`, **`/data` by default** — the
`data` volume, mounted outside the bind-mounted working tree so that nothing they
write lands in the repository; their databases live on the PostgreSQL instances
`db-predeployment` and `db-schema-checks`. The value is a path **inside the container**: a relative one resolves
against `/workspace`, the repository itself. From Git Bash, MSYS path conversion
rewrites a POSIX-looking path into a Windows one before docker sees it — `/data`
arrives as `C:/Program Files/Git/data` — so a docker command passing a container
path from Git Bash is prefixed with `MSYS_NO_PATHCONV=1`. Both scripts refuse, before
any step runs and naming the variable, a value that is not absolute or that carries a
drive letter, a `:` or a `\` (`ci/data-dir-guard.sh`, decision 16 of
`specs/SPEC-step-5b-widget-api.md`); leaving the variable unset is always right.

`docker compose run --rm dev
bash` opens an interactive shell in the same environment, and
`.devcontainer/devcontainer.json` reuses the same `dev` service so VS Code
"Reopen in Container" gives the editor that toolchain too. The Go module cache,
the Go build cache and the database's data live in named volumes mounted
outside the bind-mounted working tree, so a database never lands in the
repository and never suffers Windows bind-mount locking.

**What this environment does not prove.** Docker provides the Debian userland
and the Linux kernel, and nothing more. It does **not** exercise, and must
never be read as evidence for:

1. the systemd unit;
2. service start ordering;
3. unprivileged-LXC uid mapping;
4. `ct/install.sh`;
5. update by re-running the installer without data loss.

All five belong to step 8 and can only be validated on a real LXC. A green
container run says nothing about deployment.

## Steps

**Order of work.** Step 7 is done before step 6 (decided by the maintainer on 10 October
2026): the canvas of the step-3 mockup is built on the step-5 widget API first, and the
alerts of step 6 follow as widgets on it. The numbers are kept, because code and
documents refer to them.

|#|Step|Deliverable|Status|
|---|---|---|---|
|1|OPNsense API exploration|Verified findings document|Done|
|2|Data model and SQLite schema|Schema + model document|Done|
|3|Static HTML mockup — overview|HTML file for a representative canvas, fake data|Done|
|4|Backend: collection and storage|Collectors + persistence + tests|Done — validated against a live OPNsense 26.7 on 3 October 2026|
|5|Backend: correlation, classification, matrix|Aggregations + HTTP API + tests|In progress — 5A (correlation, classification, aggregation) implemented, **not yet validated live**: its first live run, on 5 October 2026, measured the defects `specs/SPEC-step-5a-live-corrections.md` corrects; the resolver-cache cycle (`specs/SPEC-resolver-cache-attribution.md`) attributes site names from the resolver cache first and by timing as the fallback, records the method on each attribution, resolves host names through local data and reads the processor from its stream, **implemented, not yet validated live**; 5B (the widget HTTP API, `docs/widget-api.md`; `specs/SPEC-step-5b-widget-api.md`) implemented, **not yet validated live**|
|7|Full frontend|Canvases, widgets, dashboard import/export|To do|
|6|Backend: alerts and client correlation|Alert model + API + tests|To do|
|8|Install, packaging, documentation|`ct/install.sh`, compose (opnview + PostgreSQL/TimescaleDB), README|To do|

### Step 1 — OPNsense API exploration

No code. Verify **against the official documentation** which endpoints really
expose the five sources, and in what shape. For each one: exact endpoints,
shape of the data, retention on the firewall, polling frequency it can sustain
without being loaded. If a source is not reachable through the API: say so, and
propose an alternative — never work around it by reading files on the firewall.

- Filter logs — interface, action, rule, source, destination, ports.
- NetFlow / Insight — volumes per address pair.
- DHCP leases — hostnames and MACs.
- Resolver DNS lookups — domain names per client. The resolver may be Unbound
  or Dnsmasq, and the DHCP server likewise: state how to detect which is
  active.
- **Suricata `eve.json`** — the open question of this step. Three things to
  settle:
  1. **Reachability.** Is `eve.json` exposed through the API, and in what
     form — a log-query endpoint, a streaming endpoint, a paginated search?
     Can it be consumed incrementally (cursor, offset, timestamp filter)
     rather than re-read whole?
  2. **Enabling the event types.** OPNsense logs only alerts by default.
     Determine whether the web UI exposes the `dns` / `tls` / `http` event
     types, whether it requires editing a configuration file, and whether the
     setting survives firewall upgrades. The procedure goes in the README:
     the user will have to follow it.
  3. **Volume.** Logging every DNS lookup and every TLS handshake of a whole
     network produces far more than alerts. Estimate it, and confirm that the
     application can consume the log continuously rather than letting it pile
     up on the firewall, whose disk is not sized for that.

Also in scope: discovering interfaces with their descriptions and subnets, and
discovering rules with their labels.

**Validation**: the report is credible and every endpoint is sourced.

**Outcome**: `docs/opnsense-api-survey.md`, pinned to OPNsense 26.7.3, every
endpoint cited. Three findings invalidate assumptions made above, and are
carried into the steps that follow:

1. **Suricata `dns` events do not exist.** The IDS model exposes only `http`
   and `tls` under `eveLog`; there is no `dns` output type to enable, in the
   UI or anywhere else.
2. **`tls` and `http` events can be written but not read back.** The only API
   endpoint that opens `eve.json` returns records carrying a top-level `alert`
   key and silently discards every other event type, and the generic log
   endpoint cannot open a file not named `.log`. Suricata is therefore an
   **alert source only** — it cannot name sites.
3. **Per-address-pair volume exists only at daily resolution, kept 62 days.**
   No sub-daily per-pair data exists on the firewall, so the 1 h and 24 h
   matrix periods cannot be served from Insight.

A fourth finding is a trap rather than a limit: the Unbound query endpoint
honours its time window only when the bounds arrive as JSON integers in the
request body. Any other call form returns the 1000 most recent records with
HTTP 200 and no diagnostic — silent data loss unless the collector asserts
that the rows it gets back fall inside the window it asked for.

### Step 2 — Data model and SQLite schema

Entities: interface (a VLAN, a physical link or a tunnel the firewall
terminates), client, owner, flow, blocked event,
DNS resolution, rule, domain attribution, alert, geo/ASN. There is no
TLS/HTTP observation entity: no source feeds it (step 1, finding 2), and the
schema carries nothing it cannot fill.

- East-west / north-south classification carried by the model.
- Manual interface labelling by the user, never inferred from a name.
- **Ownership likewise: assigned by the user, never inferred.** A person is an
  `owner` row and a machine points at one. The firewall does not know who owns
  what, so nothing derives an owner from a hostname, a MAC prefix or a vendor
  hint. A client with no owner assigned is the normal case and stays visible in
  any per-person view, in an explicit unassigned bucket.
- Randomised MAC (second hex digit even) marked as an unstable identity, not
  merged into phantom clients.
- **Every site-name attribution is inferred**, from resolver-lookup
  correlation — there is no second method to tell it apart from (step 1,
  finding 2). No provenance flag: a field with one possible value states
  nothing. What the model does carry is the lookup the name came from and the
  delay between that lookup and the flow, so an attribution can be judged.
- Alerts: signature, severity, source, destination, timestamp, joined to the
  client and interface models.
- Configurable retention, from a few hours to unlimited, with purge.
- Aggregate mode: volumes, interfaces, countries, operators — without domain
  names.
- Pre-computed aggregates for the 1 h / 24 h / 7 d / 30 d periods. These are
  the **primary store, not a cache over Insight**: per-pair data on the
  firewall is daily-only, and per-source data at 300 s is kept one hour.
- **Source availability is a modelled state**, not an absence of rows: per
  source, reachable / present-but-disabled / unavailable, with a timestamp and
  the probe that determined it. Every screen reads it.
- A durable ingestion cursor for `eve.json`: a per-`file_id` byte-offset
  watermark over an alert-only feed, with rotation detection, so a restart
  neither loses events nor double-counts them.

**Validation**: the schema answers all seven screens without pathological
queries.

**Outcome**: the migrations, `sql/seed.sql`, the seven representative queries
in `sql/queries/screens.sql` and `docs/data-model.md`. Step 3's widget
catalogue subsequently identified gaps between the model and the
questions the widgets ask; they are tabulated in `docs/widget-catalogue.md`,
and each is a future migration. **Two have since been closed in the migrations
themselves**, which are edited in place because nothing is deployed: G1, the
blocklist that refused a resolver lookup — its **name** observed from the API
and its **purpose** assigned by the user, never inferred from the name — and
G11, the per-person aggregates that let a per-person question outlive the
`flow` horizon. **Nine remain open** — `docs/widget-catalogue.md`, *Gaps found*, is the count
— two of them new: G12, that nothing in
the model classifies a flow as an application, and G13, that no interface
address and no address history is stored. **G9 and G10 — firewall health and telemetry — are closed**: the live-firewall
survey found every telemetry endpoint answering, and `measurement_sample` is a
provider kind that holds a sampled gauge.

### Step 3 — Static HTML mockup of a representative canvas

A single file, fake data, **mandatory stop for validation before writing the
frontend**. Its subject is a **representative canvas** — a named board composed
from widgets of `docs/widget-catalogue.md` — and not a fixed overview screen,
because the product has no fixed screens.

**The visual language is angular, dense and high-contrast.** The maintainer's
industrial palette is the reference: a `0.25rem` corner radius, system fonts
only, and a layout of a fixed top bar, a collapsible sidebar and a centred main
column. Cloudflare Radar is the compositional reference — a left rail, a scoped
header carrying the selectors, and angular cards each with a one-line
explanation under its title. Homarr is the structural reference for how tiles
are arranged, moved and resized, **its rounding explicitly excepted**. Generous
spacing, a single accent colour and numbers brought forward are retained from
the original brief.

**Charts show the resolution the data actually has.** No curve smoothing, and
no silent downsampling that can hide a single-sample spike — where a series is
aggregated to fit the pixels available, the widget says so. Area fills survive
only as a means of separating stacked series, and the line on top of a fill is
drawn through its real points. A tooltip on a stacked chart lists the full
breakdown at the hovered instant rather than the top series only. Grafana is
the reference for this, and for the degree of per-series rendering control a
widget should expose.

**Theme.** On first launch the theme follows the operating system's preference.
The user can override it afterwards, and the override persists. The industrial
palette is the default; Tokyo Night, Dracula, Nord, Rosé Pine and Catppuccin
are offered as named options at the values published on the maintainer's own
site, https://lequellec.xyz, reproduced in `docs/ui-references.md` — that site,
not each palette's upstream project, is authoritative for these five names.
Nord's upstream project publishes no light variant, but the maintainer's site
defines one, so Nord is light-capable here and no fallback is to be built.

Banned, unchanged: "cyber-defence" aesthetics, walls of dense tables, and empty
panels with no explanation.

The canvas carries recent alerts alongside recent blocked traffic, and must
degrade cleanly when Suricata is absent — an explanatory state, not an empty
panel.

The binding references for this step are `docs/ui-references.md`,
`docs/widget-catalogue.md` and `docs/dashboard-format.md`.

**Validation**: explicit sign-off on the mockup.

### Step 4 — Backend: collection and storage

Go. One service, installed and updated by a single command, with no external
data store to provision — see the storage rule under **Rules that apply to
every step** above. Prerequisite: the containerised toolchain described under
**Development and test environment** above — nothing is installed on the host.

- OPNsense API client: authentication, pagination, graceful degradation when a
  source is missing.
- Runtime discovery of interfaces, subnets and rules.
- Detection of what is actually available: resolver flavour, DHCP flavour,
  Suricata present / stopped / running on which interfaces.
- Collection scheduler at the frequencies established in step 1.
- Continuous incremental ingestion of `eve.json` with a durable cursor.
- SQLite persistence, own history independent of the firewall's retention.
- **The schema is one file, applied idempotently on every start, and there are
  no migrations.** The one deployment is the maintainer's live validation
  installation, whose history is re-collectable from the firewall (a schema change
  means rebuilding its database: step 5, *Rebuilding the database after step 5B*),
  so numbered files, a
  `schema_version` table and a runner are machinery for a problem that does not
  exist. **Migrations begin the day the product runs somewhere with data worth
  keeping**: that file becomes the baseline and the first real migration is the
  one after it.
- **Extend `sql/seed.sql` to IPv6.** It currently produces IPv4 rows only.
  Nothing in the schema interprets an address family today, so step 2 passed,
  but no IPv6 row has ever been exercised through the seven screen queries.
- First-run setup: creating the first account, then the firewall URL, the API
  key/secret, the MaxMind key and the theme — the theme defaulting to the
  operating system's preference and changeable at any time from the interface
  rather than only at setup. **This is where credentials enter the product, so
  nothing before it can collect from a real firewall.**
- MaxMind GeoLite2 City and ASN databases: downloaded on first start,
  refreshed automatically, never embedded. Without a key the map is disabled
  with a clear message and everything else keeps working.
- First `*_test.go` files, standard `testing` library.

**Validation**: real collection against an OPNsense, data in the database.

### Step 5 — Backend: correlation, classification, matrix

- Source × destination matrix: volume, allowed connections, blocked
  connections, matching rules by label. Every period is computed from
  `opnview`'s own history. ~~Only 7 d and 30 d can lean on the firewall's daily
  per-pair aggregate.~~ Struck by step 5A: the only per-pair endpoint is a live
  `traffic/top` snapshot carrying neither a port nor a protocol, and the daily
  per-pair volume is derived from `flow` rather than read from Insight
  (`docs/opnsense-api-survey.md`, *The per-pair data is a live snapshot, not
  history*, and *What `traffic/top` measures, read from source for step 5*).
- East-west / north-south classification, presented separately.
- **Site names, sole path on 26.7**: the resolver. Suricata cannot serve this
  (step 1, finding 2). Since the resolver-cache cycle, exact evidence first — the
  resolver's cache shows the flow's destination among the answers of the name its
  client looked up (`resolver_cache_answer`) — and correlating resolver lookups
  with subsequent flows as the fallback (`lookup_timing`); the method is recorded
  on each attribution. Both are inferences. Their limits — client-side caching,
  shared CDNs, DNS-over-TLS and DNS-over-HTTPS, and for the cache a record the
  polls miss — are documented unconditionally, and an attribution rate is exposed
  per client and per method. Never invent a domain: fall back to IP, country and
  operator.
- Client resolution through DHCP leases.
- Geo and ASN enrichment.
- HTTP API for the widget catalogue: **one endpoint per widget type**, taking
  that widget's declared parameters — period, scope, interface, client and the
  rest — as documented in `docs/widget-catalogue.md`, and returning both the
  data and the source-availability state each widget must render. A canvas is
  served by issuing one request per widget. **The period is a parameter of a
  widget rather than a property of a screen**, because two widgets on one
  canvas will legitimately show different periods. A multi-series endpoint
  accepts a list of series and returns a list of series, each carrying its own
  availability state, so one missing source degrades one line rather than the
  whole chart. *Implemented by 5B* (`specs/SPEC-step-5b-widget-api.md`): 26 of the
  29 presets are served at `GET /api/widget/{type}`, the three alert presets wait for
  step 6, and the contract is `docs/widget-api.md`.

**Rebuilding the database after step 5B.** Step 5B edits `schema.sql` in place, as
every step before step 8 does: it adds `source_availability.outcome`,
`rule.destination_net`, `dns_resolution.client_family`, and the tables
`opnview_heartbeat` and `opnview_downtime`. `CREATE TABLE IF NOT EXISTS` does not add
a column to a table that already exists, so **a database written by any build before
step 5B (`a1e2707` and earlier) does not open under it**: the service refuses to start
with `ErrSchemaOutdated` (`internal/store/store.go`), which names this paragraph,
rather than run on a half-applied schema. The one installation this concerns is the
maintainer's live validation deployment, and its history is re-collectable: before
the 5B build first starts there, the service is stopped and `opnview.db` — with its
`-wal` and `-shm` companions, if a crash left them — is moved aside by exact path,
never deleted, then the service starts on an empty database and collects again. The
setup wizard runs again, because the accounts and settings live in the same file;
the key file beside it is kept. What is lost is the history older than the firewall's
own retention, and the live-validation baseline of
`specs/SPEC-step-5b-widget-api.md` is therefore taken on the old build's database
before the move. Migrations still begin with step 8, when an installation holds data
somebody other than the maintainer cannot re-collect.

**Validation**: the numbers are correct, and the heuristic's attribution rate
is honest.

**What this environment cannot prove, and the live firewall must.** Step 5A
was verified from the `opnsense/core` 26.7.3 source, the surveyed documentation
and synthesised fixtures. The following are probed against a live OPNsense at
this step's validation, and each finding is recorded in
`docs/opnsense-api-survey.md`. The first live run, on 5 October 2026, answered
some; each item says which, **in proportions only** — no installation's names,
addresses or counts are recorded here.

- **Gateway status — answered for the shape, open for the figures.** The field
  names `/api/routes/gateway/status` returns are the ones read from source, and
  the `~` it writes in place of a reading it does not have was observed on every
  gateway of an installation whose gateway monitoring was disabled. Each absence
  is now named in the availability detail. Samples from a monitored gateway have
  not been observed yet.
- **Open:** the response of `/api/diagnostics/system/systemSwap`.
- **Open:** the time span one `traffic/top` sample covers, which the sampled-bytes
  measure is defined from.
- **Upstream detection — answered.** An interface carrying `gateways[]` is
  classified upstream, and the classification was right on the installation
  probed; whether a tunnel carrying `gateways[]` — a VPN client with a gateway —
  is right as upstream stays to be seen on an installation that has one. Most of its flows then turned out to be the firewall's own: about seven
  in ten flows had the firewall's upstream address as an end and no other end
  placed, which is what *This Firewall* recognition and the pairing of the two legs
  of one connection now handle (`specs/SPEC-step-5a-live-corrections.md`).
- **Open:** whether `iftop`, behind `traffic/top`, reports a client talking to
  another interface on both interfaces, counting its rate twice.
- **Open:** the FreeBSD release wording of `pf.conf(5)` against the `releng` link
  the survey cites for the release OPNsense 26.7 ships.
- **Share of host-name queriers — answered.** Unbound logged a host name rather
  than an address for a minority of lookups, and about one lookup in twenty stayed
  `unknown_hostname` although leases were collected; the matching by first label on
  both sides, `localhost` as this firewall and the stored retry address the causes
  the code admitted, and the diagnostic `Unresolved host names by cause` sorts the
  rest.
- **Attribution rate — measured, and the reason for the resolver-cache cycle.**
  About a fifth to under a third of the eligible flows were named by timing alone;
  the main loss was several distinct names looked up by the same client inside
  the five-second window. The resolver's cache dump answered, read-only, in under
  a second; by type, A and AAAA records about a third each, NS about a quarter.
  **Open:** the rate with the cache's exact evidence, per method; the share of
  eligible flows whose destination the cache covered (`live_cache_evidence_coverage`);
  how the observations grow per hour; and the share of `unknown_hostname` lookups
  the local data resolves.
- **The processor figure — answered for the source.** `getActivity` carries no
  numeric processor field and the earlier reading of it never produced a value;
  `/api/diagnostics/cpu_usage/stream` answers as a server-sent event stream, about
  one event a second, never ending. **Open:** samples from it on a live firewall,
  or the named cause of their absence.
- **Double NAT and carrier-grade NAT — a new item, and a limit.** Behind an
  upstream NAT the firewall does not see its public IPv4 address, and nothing
  `opnview` reads can supply it: no OPNsense endpoint reports it and no outbound
  call the project allows could. The *Public address* widget and the
  `ReadPublicAddresses` contract state it rather than present the upstream
  interface's address as public.

### Step 6 — Backend: alerts and client correlation

Done after step 7 (see *Order of work* above).

- Ingest Suricata alerts: signature, source, destination, timestamp. The API
  flattens the nested alert object to the signature string, so severity and
  category are resolved separately through `get_rule_info/<sid>` and cached.
- Join them to the client and interface models, so an alert names a machine
  rather than an address.
- Aggregations for the Alerts screen: over time, by client, by interface, by
  signature.
- Behave correctly with no Suricata at all: the feature is absent and says so,
  it does not fail.

**Validation**: an alert raised on the firewall shows up attributed to the
right client and interface.

### Step 7 — Full frontend

**The frontend follows the same plugin model as the backend (maintainer, 11 October
2026).** Themes, languages, widget renderers and **front-only widgets** are plugins:
a directory dropped into the installation, discovered at start, with no fork, PR,
build step or merge.
- A front-only widget is a renderer that computes and draws from data the API
  already serves, such as the data catalogue, and needs no backend part.
- A widget plugin may also carry a renderer for data its own backend part
  provides.
- The step-7 specification defines the front plugin contract (manifest,
  renderer entry point, theme tokens, strings) on the same footing as
  `docs/plugins.md`.
- **One generic settings page serves every plugin and widget (maintainer, 11
  October 2026).** It is drawn from the settings a plugin declares, optionally,
  in its manifest: type, default, bounds, choices, label, and secrets. No plugin
  writes a settings screen. Secrets are write-only: the page shows their state,
  never their value. The plugin reads what the user set through `host.settings`.

The canvas frontend, served by the binary, no exotic build chain, fonts and
scripts included in the binary. **There is no fixed screen list and no view
reachable only through a menu inside a menu**: the user creates **named
canvases**, composes each from widgets, and moves between them with **tabs
rather than menus**.

#### The frontend is modular, and that is a requirement, not a preference

The step-3 mockup is a single file, which is acceptable for a mockup and is
**not** acceptable for the product. The real frontend is composed of parts a
person who is not us can add:

- **a language is a file** — every user-visible string comes from a catalogue,
  none is a literal in a template, a handler or a script, and the user switches
  language in the interface;
- **a theme is a file** — the palettes ship as data of the same kind a third
  party can add, not as blocks in a stylesheet;
- **a widget is a directory** — its manifest, its query and its renderer live
  together, and adding one is dropping a directory in, not editing the product.

The test this rule has to pass: **somebody who has never seen the source can add
a language, a theme or a widget easily and naturally**, from the documentation
alone. If adding one means editing a file that ships with the product, the rule
is not met.

Two consequences to design rather than discover:

- The service reads these parts **from a data directory at runtime**, beside the
  defaults embedded in the binary. That does not weaken *one service, installed
  and updated by a single command, with no external data store to provision* —
  the parts are files the service reads, not a store to provision — but the
  directory, its precedence over the embedded defaults and its reload behaviour
  are part of this step.
- `docs/widget-catalogue.md`'s **shape** fields — what the shape draws, what it
  requires of its data, its parameters, its empty and absent states, its
  truncation rule — stop being prose for a human and become **the widget
  manifest's schema**. That is what makes a widget a directory rather than a
  patch.

- The widget catalogue of `docs/widget-catalogue.md`, implemented as placeable
  widgets that can be added, moved and resized on a grid.
- **A widget is a shape, and the data is a parameter.** A widget that shows one
  figure is the *same widget* whether the figure is a temperature, a lease count
  or a WAN rate. So the inventory is **twelve** shapes — one figure, ranked
  bars, a time series, a table, a feed, cards, a map, a donut, a tree, a Sankey,
  a graph, a matrix — and not a list of subjects. The count is twelve and not
  the ten guessed here because it was **derived from the presets**, plus `graph`,
  which comes from a requirement rather than from a preset;
  `docs/widget-catalogue.md`, *Why twelve*, holds the derivation and is
  authoritative. `docs/widget-catalogue.md`'s entries are **presets**: a
  shape, a query and a title, chosen because they answer a question worth
  answering. They are not twenty-nine different things to build.

  **This is the corollary of modular connectors.** A connector brings entities
  and the dimensions they can be grouped by; the shapes already know how to draw
  those. Nobody writes a widget for a plugin, and the product never ships data
  nothing can display. It is also why the plugin manifest feeds the widget
  engine and not only the store: what a connector declares *is* what a reader
  can group by.
- **The connection tree answers where a chosen subject goes preferentially** —
  an interface, a client or an owner, picked by the reader, with what it reaches
  ranked. The step-3 mockup rooted it at the firewall instead, which is true of
  everything on the page and so tells the reader nothing; that root came from a
  research document's reading of a screenshot, not from any requirement.
- Named canvases with tabs, each carrying the widgets the user put on it.
- The dashboard file format of `docs/dashboard-format.md`, with import, export
  and the two repair surfaces — a highlighting JSON/YAML editor and a no-code
  selector populated from what this installation actually has.
- The theme system: the industrial palette by default, the five named palettes
  as options, the theme following the operating system on first launch with a
  persisting override — each palette a file of the same kind a third party adds.
- The string catalogue and the language picker, with English as the source
  language and no user-visible literal anywhere in the code.

**The seven queries in `sql/queries/screens.sql` remain authoritative and are
not deleted.** They are the query work this step was really carrying, and every
widget states which of them it reuses, adapts or replaces.

**No explanatory copy in the interface.** A title names, a figure states, a unit
qualifies, a degraded state is named in a word. Nothing explains the interface to
its reader.

#### What the step-3 mockup proved the interface has to be

Each of these was found by using that mockup, and each was a defect in it. They
are requirements here, not observations:

- **The page does not rebuild under the reader's hands.** A live view refreshes
  by reconciling, never by replacing, and never touches a subtree holding the
  focus or a selection. In the mockup a two-second rebuild meant a name could not
  be typed at ordinary speed, a MAC could not be selected and copied, and an
  unapplied edit was silently discarded — three critical failures, one cause.
- **Inspecting is not editing.** Every name and every figure — a client row, a
  rule, a domain, a matrix cell, a signature, a tree node — opens a detail, and
  that detail is a pivot rather than a dead end. In the mockup the only way to
  look at a machine was to repoint a widget's reference, which was permanent and
  had no undo.
- **Scope belongs to the canvas, beside the period.** Interface, client and
  owner, with a per-widget override that says so. Scoping through a gear, one
  widget at a time, is not a filter.
- **Navigation stays on screen.** Tabs and the rail do not scroll away from a
  page that is several screens tall.
- **A destructive action confirms, or can be undone.** Removing a person took
  four dated assignments with it, on one click, with neither.
- **Every control offered changes what is drawn**, or it is not offered. More
  than half the mockup's declared parameter surface was decoration.
- **A chooser may explain; a widget may not.** The copy rule above governs the
  canvas. A picker that lists twenty-four widget names and nothing else gives the
  reader nothing to choose on.
- **A figure the interface cannot show is not shown as a fragment.** No truncated
  address, no clipped label, no drawing whose names are dropped — a shortened
  address reads as a different address.

**Validation**: full walkthrough of a representative set of canvases on real
data.

### Step 8 — Install, packaging, documentation

- `ct/install.sh` aligned with `community-scripts/ProxmoxVE` conventions:
  unprivileged Debian LXC, sensible defaults, advanced mode (CPU, RAM, disk,
  storage, bridge, VLAN, DHCP or static IP), systemd service, URL printed at
  the end, update by re-running the same command without data loss. Asks
  **nothing** about OPNsense or MaxMind.
- `docker-compose.yml` for non-Proxmox users.
- The single command installs Docker Engine and its compose plugin when absent
  (an unprivileged Proxmox LXC needs nesting enabled), writes the compose file
  and a generated database credential into the installation directory, and
  starts both containers. Re-running it updates: it pulls the pinned images and
  restarts, keeping the database volume and the data directory. Database
  version bumps follow the procedure each release documents.
- README: problem solved, screenshots of **representative canvases with the
  dashboard files that produced them committed as examples** — which has a
  second benefit, since those files exercise import on every clone — one-line
  install, how to obtain the
  OPNsense API and MaxMind keys, **how to enable the resolver query log**,
  what an internal-interface IDS is and is not for, an
  honest limitations section, a factual section on the data collected and what
  can be inferred from it, the three outbound calls. Licensed under MIT
  (`LICENSE`).

**Validation**: successful install from scratch on a PVE node.

### Push sources: syslog and NetFlow (maintainer, 12 October 2026)

Plugins may receive data **pushed** by the firewall, as well as pull it through the broker:
- **syslog**, RFC 3164 and 5424, over UDP and TCP;
- **NetFlow v9 / IPFIX**, over UDP.

The user configures OPNsense to send to opnview. opnview itself still never writes to the firewall.

**The core stays agnostic.** It holds:
- the listeners;
- a generic decoder for each protocol: the syslog header, and NetFlow template decoding;
- routing by subscription.

It holds no knowledge of any program's message format.

A plugin declares in its manifest:
- the source (`syslog` or `netflow`);
- a header filter (for syslog, the `program`);
- for syslog, a named-group regular expression applied to the message;
- the output table and its typed columns, which become a TimescaleDB hypertable on its time column.

A syslog line that no plugin subscribes to is dropped at the header, at no cost.

The specification settles them in Phase C, part 2 of the backend-completion cycle:

- **Typed columns use the plugin type vocabulary** (`ip`, `mac`, `instant`, `integer`…), mapped to native PostgreSQL types such as `inet` and `timestamptz`. They are not free SQL type strings. This keeps validation, compression and the data catalogue's roles.
- **A message a regex cannot express**, such as filterlog's CSV with its many variants, may name an optional JavaScript parse function. The regex stays the fast path.
- **Only the configured firewall is accepted as a sender.** Spoofed UDP is never stored.
  - TCP syslog uses RFC 6587 framing, octet counting or newline, detected per connection; OPNsense sends newline-framed messages (survey, *Push sources*, S2).
  - Receive buffers are bounded. A drop is counted and recorded as a gap, never silently.
- **Timestamps.** RFC 3164 has no year and no zone. The firewall's measured UTC offset applies. NetFlow uses its own export time.
- **NetFlow interface indexes** are mapped to OPNsense interfaces through the API, a read through the broker.
- **One catalogue.** Pushed sources appear in the API catalogue and the data catalogue like pulled ones. A plugin may declare that a pushed source replaces a polled endpoint, as for event streams: polling stops while the push is alive and resumes when it stops.
- **One decoding, several subscribers.** Several plugins subscribed to the same program or flow share one decoding pass. Each writes only its own declared columns.

NetFlow records are joined to the logged connections as a second measure (Phase C, part 2), whatever interfaces the export captures: each record is joined from the interfaces it names, and each direction of a connection is counted once (decision 15d of the backend-completion spec, which supersedes 15b).

## Superseded decisions

Recorded so they do not resurface.

Correction of 2026-09-23, applied directly by the maintainer rather than
through a cycle, after inspection found the schema naming an OPNsense object
with a word OPNsense does not use:

- **`segment` is replaced by `interface`, everywhere.** The entity, its
  columns, the queries, the seed, the purge, the schema checks and every
  document. `segment` was invented before any research existed; OPNsense calls
  the thing an interface and always did.
- **`device` now means only the network device**, as OPNsense means it. The
  machine on the network is a `client`, the word Kea, Dnsmasq and Unbound all
  use for it. The DHCP option-61 identifier keeps its own name,
  `dhcp_lease.dhcp_client_id`, so it cannot be confused with the foreign key.
- **An `owner` entity is added**, because a per-person view needs a notion of a
  person and the model had none. It is `opnview`'s own term, deliberately: no
  product it reads has one.
- Nothing was deployed, so both renames were made **in the migrations in
  place**, exactly as the provider-neutral change was.

Revision of 2026-09-23, after the interface and dashboard-format research
(`docs/ui-references.md`, `docs/widget-catalogue.md`,
`docs/dashboard-format.md`):

- **The seven fixed screens are replaced by named canvases.** Step 7 listed
  Overview, Matrix, Interface, Client, Blocked, Alerts and Map as screens
  reachable through a menu. The product has no fixed screens: the user composes
  named canvases from widgets and moves between them with tabs. The seven
  queries in `sql/queries/screens.sql` are untouched and stay authoritative.
- **The rule that made a light theme the default, and dark merely available,
  is replaced.** The theme follows the operating system on first launch, the
  override persists, the industrial palette is the default and the five named
  palettes are options. The old rule contradicted the default palette's own
  code, which follows the OS and has no manual override at all.
- **UniFi Network is no longer the aesthetic reference, and cards are not
  rounded.** The language is angular: the industrial palette's `0.25rem`
  radius and system fonts, Cloudflare Radar for composition, Homarr for
  structure with its rounding excepted. The three bans survive unchanged.
- **The softened, smoothed chart treatment step 3 used to ask for is
  withdrawn.** The maintainer's charting reference is
  Grafana, and his reason is that it is the only one without the over-smoothed
  quality. Charts show the resolution the data actually has. Area fills survive
  only to separate stacked series, with the line through real points.
- **"HTTP API for the screens, period selector everywhere" is replaced** by one
  endpoint per widget type, with the period as a widget parameter.
- **"Single Go binary" is replaced** by one service installed and updated by a
  single command, with no external data store to provision and storage engines
  as embedded libraries. The permitted and forbidden lists are under *Rules
  that apply to every step*.

Revision of 2026-09-21, after the step-1 API survey
(`docs/opnsense-api-survey.md`, OPNsense 26.7.3):

- **Suricata is no longer a site-name source.** `dns` events do not exist and
  `tls` / `http` events cannot be read back through the API. The revision
  recorded below, which demoted the DNS × flow heuristic to a fallback, is
  itself superseded: that heuristic is the only site-name path on 26.7, and
  the README's limitations section applies to it unconditionally again.
  Suricata stays a data source, for alerts alone — the Alerts screen and the
  eight-step plan are unchanged.
- **The matrix cannot lean on Insight for its short periods.** Per-address-pair
  volume is daily-only, so `opnview`'s own history is the primary store rather
  than a cache.

Revision of 2026-09-21, after Suricata was added as a data source:

- **The DNS × flow heuristic is no longer the primary way to name sites.** It
  is demoted to a fallback for installations without Suricata. It stays
  implemented; it is no longer the main path, and the README's limitations
  section applies to it conditionally rather than unconditionally.
- **Four data sources became five**, and the five-source list above replaces
  the earlier one.
- **Six screens became seven**: the Alerts screen is new, and the Client
  screen gains its alerts.
- **Seven steps became eight**: alerts and client correlation are their own
  backend step, between the matrix and the frontend. Step numbers shifted
  accordingly — the frontend is now step 7 and packaging step 8.
